# Abrar's Secret Recipes Website

## Files
- index.html — Home page
- products.html — Products page
- about.html — About page
- contact.html — Contact page
- order.html — Order and sample request page
- style.css — Website styling
- script.js — Navigation and WhatsApp form functionality

## Preview locally
Open `index.html` in a browser. For a better local development experience, use VS Code with the Live Server extension.

## Publish with GitHub Pages
1. Create a **Public** repository on GitHub.
2. Upload all seven website files directly into the repository root (not inside another folder).
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then Save.
6. Wait for the Pages deployment and open the published URL.

## Important notes
- This is a static website and does not need a paid backend.
- Order and contact forms prepare a message and open WhatsApp. The visitor must press Send in WhatsApp.
- No online payment, database, or private order dashboard is included.
- Images are loaded from Unsplash URLs and Google Fonts are loaded online, so those visual assets require an internet connection.
- Replace or remove any image that does not accurately represent the actual product.
- Do not upload confidential recipe formulas, passwords, API keys, or private customer data to a public repository.
