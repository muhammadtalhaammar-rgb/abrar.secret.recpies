/* Abrar's Secret Recipes - static website interactions */
(() => {
  "use strict";

  const WHATSAPP_NUMBER = "923216674171";

  // Current year in footer
  document.querySelectorAll("[data-year]").forEach((node) => {
    node.textContent = new Date().getFullYear();
  });

  // Mobile navigation
  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  if (menuButton && nav) {
    menuButton.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(isOpen));
      menuButton.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
    });
    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("open");
        menuButton.setAttribute("aria-expanded", "false");
      });
    });
  }

  // Prefill order page from product/sample links
  const params = new URLSearchParams(window.location.search);
  const requestedProduct = params.get("product");
  const requestedSample = params.get("sample");
  const requestType = document.getElementById("requestType");

  if (requestedSample === "yes" && requestType) {
    requestType.value = "Free sample request";
  }

  if (requestedProduct) {
    const productBoxes = document.querySelectorAll('input[name="products"]');
    let matched = false;
    productBoxes.forEach((box) => {
      if (box.value.toLowerCase() === requestedProduct.toLowerCase()) {
        box.checked = true;
        matched = true;
      }
    });
    // If a product link has a slightly different label, put it in the additional message.
    if (!matched) {
      const message = document.querySelector('textarea[name="message"]');
      if (message) message.value = `I am interested in: ${requestedProduct}`;
    }
  }

  // Forms intentionally use WhatsApp because GitHub Pages is static and has no backend.
  document.querySelectorAll(".whatsapp-form").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();

      if (!form.reportValidity()) return;

      const formData = new FormData(form);
      const type = form.dataset.formType;
      const lines = [];

      if (type === "order") {
        lines.push("Assalam-o-Alaikum! I would like to make an inquiry / order.");
        lines.push("");
        lines.push("CUSTOMER DETAILS");
        appendField(lines, "Full name", formData.get("name"));
        appendField(lines, "Restaurant / business", formData.get("business"));
        appendField(lines, "Mobile number", formData.get("phone"));
        appendField(lines, "WhatsApp number", formData.get("whatsapp"));
        appendField(lines, "Email", formData.get("email"));
        appendField(lines, "City", formData.get("city"));
        appendField(lines, "Address", formData.get("address"));
        appendField(lines, "Restaurant type", formData.get("restaurantType"));

        const products = formData.getAll("products");
        appendField(lines, "Interested products", products.join(", ") || "Not selected");
        appendField(lines, "Estimated quantity", formData.get("quantity"));
        appendField(lines, "Request type", formData.get("requestType"));
        appendField(lines, "Delivery / pickup", formData.get("fulfilment"));
        appendField(lines, "Additional requirements", formData.get("message"));
      } else {
        lines.push("Assalam-o-Alaikum! I have a business inquiry.");
        lines.push("");
        appendField(lines, "Name", formData.get("name"));
        appendField(lines, "Restaurant / business", formData.get("business"));
        appendField(lines, "Phone", formData.get("phone"));
        appendField(lines, "Email", formData.get("email"));
        appendField(lines, "Message", formData.get("message"));
      }

      lines.push("");
      lines.push("Sent from Abrar's Secret Recipes website.");
      const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(lines.join("\n"))}`;
      window.open(url, "_blank", "noopener,noreferrer");
      showFormNotice(form, "WhatsApp is opening with your inquiry. Please review the message and press Send in WhatsApp.");
    });
  });

  function appendField(lines, label, value) {
    if (value !== null && value !== undefined && String(value).trim() !== "") {
      lines.push(`${label}: ${String(value).trim()}`);
    }
  }

  function showFormNotice(form, message) {
    let notice = form.querySelector(".form-success");
    if (!notice) {
      notice = document.createElement("p");
      notice.className = "form-success";
      notice.setAttribute("role", "status");
      form.appendChild(notice);
    }
    notice.textContent = message;
  }
})();